const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');
const cron = require('node-cron');
const session = require('express-session');
const shortId = require('shortid');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // For form data

// Session setup
app.use(
    session({
        secret: 'mySecret',
        resave: false,
        saveUninitialized: false,
    })
);

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// PORT
const PORT = parseInt(process.env.PORT, 10) || 3000;

// MongoDB connection
const mongoAtlasUri =
    process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/pastebin';

mongoose.connect(mongoAtlasUri, { serverSelectionTimeoutMS: 3000 });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// --- Schemas and Models ---

// User schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

const User = mongoose.model('User', userSchema);

// Paste schema
const pasteSchema = new mongoose.Schema({
    _id: { type: String, default: shortId.generate },
    title: String,
    content: String,
    created_at: { type: Date, default: Date.now },
    expiration_date: Date,
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});

// Static method for auto-delete
pasteSchema.statics.deleteExpiredPastes = async function () {
    try {
        const currentDate = new Date();
        await this.deleteMany({ expiration_date: { $lte: currentDate } });
        console.log('Expired pastes deleted successfully');
    } catch (err) {
        console.error('Error deleting expired pastes:', err);
    }
};

const Paste = mongoose.model('Paste', pasteSchema);

// --- Routes ---

// Serve login/register pages
app.get(['/', '/login_page'], (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'login.html'))
);

app.get('/register_page', (req, res) =>
    res.sendFile(path.join(__dirname, 'public', 'register.html'))
);

// Serve pastes page
app.get('/pastes', (req, res) => {
    if (req.session?.userId) {
        res.sendFile(path.join(__dirname, 'public', 'home.html'));
    } else {
        res.redirect('/login_page');
    }
});

// Register
app.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, email, password: hashedPassword });
        await user.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Login
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        req.session.userId = user._id;
        res.status(200).json({ message: 'Login successful' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Logout
app.post('/logout', (req, res) => {
    req.session.destroy();
    res.status(200).json({ message: 'Logged out successfully' });
});

// Current user
app.get('/current_user', async (req, res) => {
    if (req.session?.userId) {
        const user = await User.findById(req.session.userId);
        res.json(user);
    } else {
        res.status(401).json({ message: 'Not logged in' });
    }
});

// --- Paste API ---

// Create paste
app.post('/api/pastes', async (req, res) => {
    try {
        const { title, content, expiration_date } = req.body;
        const author = req.session.userId;
        const paste = new Paste({ title, content, expiration_date, author });
        await paste.save();
        res.status(201).json(paste);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get all pastes
app.get('/api/pastes', async (req, res) => {
    try {
        const userId = req.session.userId;
        const pastes = await Paste.find({ author: userId });
        res.json(pastes);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get single paste
app.get('/api/pastes/:id', async (req, res) => {
    try {
        const paste = await Paste.findById(req.params.id);
        if (!paste) return res.status(404).json({ message: 'Paste not found' });
        res.json(paste);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Render paste page
app.get('/api/pastes/:id/page', async (req, res) => {
    try {
        const paste = await Paste.findById(req.params.id);
        if (!paste) return res.status(404).json({ message: 'Paste not found' });

        const author = await User.findById(paste.author);
        paste.author = author;

        res.render('paste', { paste });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update paste
app.put('/api/pastes/:id', async (req, res) => {
    try {
        const { title, content, expiration_date } = req.body;
        const updatedPaste = await Paste.findByIdAndUpdate(
            req.params.id,
            { title, content, expiration_date },
            { new: true }
        );
        res.json(updatedPaste);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Delete paste
app.delete('/api/pastes/:id', async (req, res) => {
    try {
        await Paste.findByIdAndDelete(req.params.id);
        res.status(204).send();
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// --- Start Server ---
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);

    // Auto-delete expired pastes every hour
    cron.schedule('0 * * * *', async () => {
        console.log('Running auto-deletion task...');
        await Paste.deleteExpiredPastes();
    });
});

module.exports = app;
